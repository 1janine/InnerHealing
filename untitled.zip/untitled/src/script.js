document.addEventListener('DOMContentLoaded', () => {
  console.log("Newspaper layout loaded.");
});

const audio = document.getElementById("backgroundMusic");
const playPauseBtn = document.getElementById("playPauseBtn");
let isPlaying = false;

playPauseBtn.addEventListener("click", function() {
  if (isPlaying) {
    audio.pause();
    playPauseBtn.src = "https://static-00.iconduck.com/assets.00/musical-note-emoji-2048x2034-4cope7is.png";  
  } else {
    audio.play();   
    playPauseBtn.src = "https://static-00.iconduck.com/assets.00/musical-note-emoji-2048x2034-4cope7is.png";  
  }
  isPlaying = !isPlaying;
});

window.addEventListener('scroll', function() {
  const headline = document.querySelector('.headline');
  const scrollY = window.scrollY;
  
 headline.style.transform = `translateY(${scrollY * 0.3}px)`;
});
window.addEventListener('scroll', function() {
  const headline = document.querySelector('.headline');
  const scrollY = window.scrollY;

  if (scrollY <= 200) { 
headline.style.transform = `translateY(${scrollY * 0.3}px)`;
  } else {
headline.style.transform = `translateY(60px)`;
  }
});

